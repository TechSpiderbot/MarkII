#ifndef MBED_KinematicsV1_H
#define MBED_KinematicsV1_H

#include "setup.h"
#include "math.h"
#include "MemorySpace.h"
/*
* Defined values of the calculated robot model
*/
#define Coxa            52.8
#define Femur           63.92
#define Tibia           145.12
#define Zoffset         42
#define PI              3.14159265359    
                                     
                                     // MemorySpace locations:
#define storeHip             1       // Hip degrees
#define storeArm             2       // arm degrees
#define storeToo             3       // too degrees
#define storeHeight          4       //arm height
#define storDistance         5       //too distance

#define storeErr             6       // error flags

#define fullLoop        200

class Kinematics : public setup{
public:

    /*
    * memorySetup 
    *
    * In the setup the unit addresses are defined in the memory space 
    * 
    * The values that are used in the memorySetup are from positions used in the Setup
    * 
    */
    
    void SetupMemory(MemorySpace &mem);
    
    /*
    * legControl
    *
    * The legControl makes use of 4 diferent pointers:
    *
    * ID: The ID is a number that can be used to select one of the legs
    * Give an interger value between [10..50] to select a leg of the robot
    *   10  =   Leg Back Left
    *   20  =   Leg Front Left
    *   30  =   Leg Back Right    
    *   40  =   Leg Front Right
    *   50  =   Container
    *
    * Memory: The memory is an arrays that safes all postions of all the servomotors.
    *
    * height: The height says something about the distance from the ground the underside of the robot in mm
    * Give an interger value between 0 en the maximum length(Femur + Tibia) of your robot legs.
    * In this sample the value is between [0..209]mm
    *
    * distance: The distande says something about the length from the middle of the hip till the too.
    * Give an integer value between [53..180]  
    * Calculate the Alpha and Beta corners
    *
    */
    
    void unitPosition(int ID,MemorySpace &mem,int rotation,int height, int distance);
    
    /*
    * executeContrl:
    * ###
    * For this test all:
    * 
    * hip rotations are excluded and set to a static value
    *
    * This test includes only the height position of the robot
    *
    * Touch:  true  =  enable: the unit will change the height till it hit the ground
    *         false =  disable 
    */
    
    void exeKinematics(MemorySpace &mem);
    
private:   
    /*
    * Kinematics variables
    */
    float L, dutyA, dutyB, _offset;
    
    //
    int servoAddress,servoType;
    
    int flagStatus;
    int lastValue;
    int newValue;
    
    void checkCalculation(int &ID,MemorySpace &cpyMem,int &rotation,float &A,float &B);
    
    void storeErrorMsg(int &ID,MemorySpace &cpyMem);
    void storeHeightDistance(int &ID,MemorySpace &cpyMem,int &height, int &distance);
          
    /*
    * storeData:
    *
    * Internal loop: When a calculation went well(correct) the function will check of the given value is between [0..180], because that's the minimum and
    * maximum value in degrees that the servomotors can turn. If the value is not between [0..180] it will give an error flag.
    * 
    * The error flag will be given because it will give errors in the kinematic behaviour when you'll use the values.
    * this function will show al times the  Alpha and Beta corners (in degrees)
    */
    void storeData(int &ID,MemorySpace &cpyMem,int &rotation,float &A,float &B);   
    
    /*
    *
    *
    */
    
    void exeServo(int ID,MemorySpace &cpyMem);
};
#endif
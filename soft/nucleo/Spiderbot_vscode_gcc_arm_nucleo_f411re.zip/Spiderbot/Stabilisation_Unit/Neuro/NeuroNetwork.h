#ifndef MBED_NeuroNetwork_H
#define MBED_NeuroNetwork_H

//#define DEBUG 
//#define DEBUG_SUCCES
#define DISPLAY

#define LinksAchter     10
#define LinksVoor       20
#define RechtsAchter    30
#define RechtsVoor      40

#include "mbed.h"
#include "setup.h"
#include "Serial.h"
#include "MemorySpace.h"
#include "KinematicsV1.h"
#include "net.h"

                                // MemorySpace locations:
#define memoryHip       1       // Hip degrees
#define memoryDistance  5       //too distance

struct TeachStuff{
    int sample1;
    int sample2;
    
    float targ1;  // LA
    float targ2;  // LV
    float targ3;  // RA
    float targ4;  // RV
};

class NeuroNetwork{
public:
    void testRun();
    
    void stabilisationRun(bool);
    
    
private:
    static int max_Val;
    static int neutral_Val;
    static int min_Val;
    
    static float max_output;
    static float med_output;
    static float min_output; 
    
    static int TRAINING; 
    int trainingPass;
    double averageError;
    static float Succes;
    
    // values for Gyroscoop
    float pitch,roll;
    float oldPich,oldRoll;
    int legID;
    int rotation;
    int height;
    int distance;
    int flag;
    Ticker tick;
    
    void randLevelWeight(int *s);
    void targetTeaching(TeachStuff &data);   
};

#endif
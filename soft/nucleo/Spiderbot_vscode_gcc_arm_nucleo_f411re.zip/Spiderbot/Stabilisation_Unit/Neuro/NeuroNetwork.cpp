#include "NeuroNetwork.h"

Serial pc4(USBTX,USBRX);
setup Settings;
Kinematics kinematOutput; 
Ticker GyroTicker;
MemorySpace mem;
TeachStuff data;

int NeuroNetwork::TRAINING = 2000;
float NeuroNetwork::Succes = 0.0009;
// max input values:
int NeuroNetwork::max_Val = 1;
int NeuroNetwork::neutral_Val = 0;
int NeuroNetwork::min_Val = -1;

// max output targets(height):
/* height = (max_output = 0.90 * 100) 
    =   90mm 
*/ 
float NeuroNetwork::max_output = 0.90;
float NeuroNetwork::med_output = 0.65;
float NeuroNetwork::min_output = 0;

void NeuroNetwork::randLevelWeight(int *s){
    if(*s == 3){
            *s = min_Val;
    }
    else if(*s == 2){
        *s = neutral_Val;
    }
    else if(*s == 1){
        *s = max_Val;
    }
}

// stabilisation motion.
void NeuroNetwork::targetTeaching(TeachStuff &data){
   // pitch = sample1               roll = sample2
   if((data.sample1 == max_Val) && (data.sample2 == neutral_Val)){
        // leaning to the front
        data.targ1 = min_output;
        data.targ2 = max_output;
        data.targ3 = min_output;
        data.targ4 = max_output;
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == min_Val) && (data.sample2 == neutral_Val)){
        // leaning to the back       
        data.targ1 = max_output;
        data.targ2 = min_output;
        data.targ3 = max_output;
        data.targ4 = min_output;
    
    }
    // pitch = sample1               roll = sample2
    else if ((data.sample1 == neutral_Val) && (data.sample2 == neutral_Val)){
        // stabalized
        data.targ1 = med_output;
        data.targ2 = med_output;
        data.targ3 = med_output;
        data.targ4 = med_output;
    
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == neutral_Val) && (data.sample2 == max_Val)){
        // leaning to the Left
        data.targ1 = max_output;
        data.targ2 = max_output;
        data.targ3 = min_output;
        data.targ4 = min_output;
    
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == neutral_Val) && (data.sample2 == min_Val)){
        // leaning to the Right
        data.targ1 = min_output;
        data.targ2 = min_output;
        data.targ3 = max_output;
        data.targ4 = max_output;
    
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == max_Val) && (data.sample2 == max_Val)){
        // leaning to the front Left
        data.targ1 = min_output;
        data.targ2 = max_output;
        data.targ3 = min_output;
        data.targ4 = med_output;
    
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == max_Val) && (data.sample2 == min_Val)){
        // leaning to the front right
        data.targ1 = min_output;
        data.targ2 = med_output;
        data.targ3 = med_output;
        data.targ4 = max_output;
    
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == min_Val) && (data.sample2 == min_Val)){
        // leaning to the back right
        data.targ1 = med_output;
        data.targ2 = min_output;
        data.targ3 = max_output;
        data.targ4 = med_output;
    
    }
    // pitch = sample1               roll = sample2
    else if((data.sample1 == min_Val) && (data.sample2 == max_Val)){
        // leaning to the back left
        data.targ1 = max_output;
        data.targ2 = med_output;
        data.targ3 = med_output;
        data.targ4 = min_output;
    }
}

void NeuroNetwork::stabilisationRun(bool DONE){
    #ifdef DEBUG_SUCCES
    pc4.printf("stabilisationRun: ACTIVE \n\r");
    #endif
        
    // e.g., {2, 8, 4}
    vector<unsigned> topology;
    topology.push_back(2);
    topology.push_back(8);
    topology.push_back(4);
    Net myNet(topology);
    
    vector<double> inputVals, targetVals, resultVals; 

    trainingPass = 0;
    data.targ1 = 0;
    data.targ2 = 0;
    data.targ3 = 0;
    data.targ4 = 0;
    
    //while(trainingPass < TRAINING){
    #ifdef DEBUG_SUCCES
    pc4.printf("Teaching NeuroNetwork\n\r"); 
    #endif
        
    #ifdef DISPLAY
    
    // Teaching
    
    wait(2);
    #endif
        
    do{
        ++trainingPass;           
        
        // generate new inputValues:
        inputVals.clear();
        
        data.sample1 = rand() % 3 + 1;
        data.sample2 = rand() % 3 + 1;
        
        // set a weight to sample
        randLevelWeight(&data.sample1);
        randLevelWeight(&data.sample2);
        
        // set the target value
        targetTeaching(data);
        
        inputVals.push_back(data.sample1);
        inputVals.push_back(data.sample2);
        
        #ifdef DEBUG
        pc4.printf("Inputs: ");
        for(int i = 0; i < inputVals.size(); ++i){ 
            pc4.printf("| %2.0f",inputVals[i]);
        }
        pc4.printf("\n\r");
        #endif
        
        myNet.feedForward(inputVals);
        
        // collect the net's actual results:
        myNet.getResults(resultVals);
        
        #ifdef DEBUG
        pc4.printf("Outputs:");
        for(int i = 0; i < resultVals.size(); ++i){
            pc4.printf(" %f",resultVals[i]);
        }
        pc4.printf("\n\r");
        #endif
              
        // train the net what the outputs shoulld have been:
        targetVals.clear();
        targetVals.push_back(data.targ1);
        targetVals.push_back(data.targ2);
        targetVals.push_back(data.targ3);
        targetVals.push_back(data.targ4);
        
        #ifdef DEBUG
        pc4.printf("Target:");
        for(int i = 0; i < targetVals.size(); ++i){
            pc4.printf(" %2.2f",targetVals[i]);
        }
        pc4.printf("\n\r");
        #endif
        
        assert(targetVals.size() == topology.back());
            
        myNet.backProp(targetVals);
        averageError = myNet.getRecentAverageError();
            
        #ifdef DEBUG
        pc4.printf("Net recent average error: %f \n\r \n\r" ,myNet.getRecentAverageError());
        #endif
    } while(averageError > Succes);
        
    #ifdef DEBUG_SUCCES
    pc4.printf("DONE! \n\r"); 
    pc4.printf("Pass = %i: \n\r",trainingPass);
    #endif
        
    #ifdef DISPLAY
    //Settings.debugDisplay(0,0,0);
    //Settings.debugDisplay(11,trainingPass,0);
    // cooldown 2 sec
     wait(2);
    //Settings.debugDisplay(0,0,0);
    #endif
    
    // replace true with memorie cell            
    while(true){
        //use sensor inputs to control the servo height
        // generate new inputValues:
        inputVals.clear();      
          
        //read Gyro data &yaw, &pitch, &roll  
        pitch = Settings.readGyroData(false,true,false);
        roll = Settings.readGyroData(false,false,true);
        
        #ifdef DEBUG
        pc4.printf("pitch: %2.4f\n\r",pitch);
        pc4.printf("roll : %2.4f\n\r",roll);
        #endif
                
        #ifdef DISPLAY
        //Settings.debugDisplay(12,pitch,roll);
        #endif
            
        inputVals.push_back((pitch / 100));
        inputVals.push_back((roll  / 100));
                
        #ifdef DEBUG_SUCCES
        pc4.printf("Inputs: ");
        for(int i = 0; i < inputVals.size(); ++i){ 
            pc4.printf("| %2.6f",inputVals[i]);
        }
        pc4.printf("\n\r");
        #endif
                
        myNet.feedForward(inputVals);
                
        // collect the net's actual results:
        myNet.getResults(resultVals);
                
        #ifdef DEBUG_SUCCES
        pc4.printf("Outputs:");
        for(int i = 0; i < resultVals.size(); ++i){
            pc4.printf(" %f",resultVals[i]);
        }
        pc4.printf("\n\r");
        #endif

        //  unitPosition( ID,MemorySpace,rotation,height,distance )    
        distance = 100;
        kinematOutput.unitPosition(LinksAchter  ,mem    ,mem.lastPosition[((LinksAchter / 10)- 1)][memoryHip]    ,(resultVals[0] * 100),mem.lastPosition[((LinksAchter / 10)- 1)][memoryDistance]); 
        kinematOutput.unitPosition(LinksVoor    ,mem    ,mem.lastPosition[((LinksVoor / 10)- 1)][memoryHip]      ,(resultVals[1] * 100),mem.lastPosition[((LinksVoor / 10)- 1)][memoryDistance]);
        kinematOutput.unitPosition(RechtsAchter ,mem    ,mem.lastPosition[((RechtsAchter / 10)- 1)][memoryHip]   ,(resultVals[2] * 100),mem.lastPosition[((RechtsAchter / 10)- 1)][memoryDistance]);
        kinematOutput.unitPosition(RechtsVoor   ,mem    ,mem.lastPosition[((RechtsVoor / 10)- 1)][memoryHip]     ,(resultVals[3] * 100),mem.lastPosition[((RechtsVoor / 10)- 1)][memoryDistance]);
        kinematOutput.exeKinematics(mem); 
    }  
}

void NeuroNetwork::testRun(){
    #ifdef DEBUG
    pc4.printf("test  = active \n\r");
    #endif
    
    // e.g., {3, 2, 1}
    vector<unsigned> topology;
    topology.push_back(2);
    topology.push_back(8);
    topology.push_back(1);
    Net myNet(topology);
    
    
    vector<double> inputVals, targetVals, resultVals; 
    //myNet.feedForward(inputVals);
    //myNet.backProp(targetVals);
    //myNet.getResults(resultVals);
    int trainingPass = 0;
    int targ1 = 0;
    
    while(trainingPass < 1000){
        ++trainingPass;
        
        #ifdef DEBUG
        pc4.printf("Pass = %i: ",trainingPass);
        #endif
        
        // generate new inputValues:
        inputVals.clear();
        
        int sample1 = (int)(2.0 * rand() / double(RAND_MAX)); //rand() % 180;
        int sample2 = (int)(2.0 * rand() / double(RAND_MAX));
        
        if((sample1 == 0) && (sample2 == 0)){
            targ1 = 0;
        }
        else if((sample1 == 0) && (sample2 == 1)){
            targ1 = 1;
        }
        else if((sample1 == 1) && (sample2 == 0)){
            targ1 = 1;
        }
        else if((sample1 == 1) && (sample2 == 1)){
            targ1 = 0;
        }
        inputVals.push_back(sample1);
        inputVals.push_back(sample2);
        
        #ifdef DEBUG
        pc4.printf("Inputs: ");
        for(int i = 0; i < inputVals.size(); ++i){ 
            pc4.printf("| %2.0f",inputVals[i]);
        }
        pc4.printf("\n\r");
        #endif 
        myNet.feedForward(inputVals);
        
        // collect the net's actual results:
        myNet.getResults(resultVals);
        
        #ifdef DEBUG
        pc4.printf("Outputs:");
        for(int i = 0; i < resultVals.size(); ++i){
            pc4.printf(" %f",resultVals[i]);
        }
        pc4.printf("\n\r");
        #endif
        
        // train the net what the outputs shoulld have been:
        targetVals.clear();
        targetVals.push_back(targ1);
        
        #ifdef DEBUG
        pc4.printf("Target:");
        for(int i = 0; i < targetVals.size(); ++i){
            pc4.printf(" %2.0f",targetVals[i]);
        }
        pc4.printf("\n\r");
        #endif
        
        assert(targetVals.size() == topology.back());
        
        myNet.backProp(targetVals);
        
        #ifdef DEBUG
        pc4.printf("Net recent average error: %f \n\r \n\r" ,myNet.getRecentAverageError());
        #endif
    }
   #ifdef DEBUG 
   pc4.printf("DONE! \n\r"); 
   #endif
}

#ifndef MBED_Control_PS2_H
#define MBED_Control_PS2_H

#include "mbed.h"
#include "Serial.h"
#include <string>
#include "WalkOrient.h"
#include "btnValues.h"

// skps protocol
#define p_select        0
#define p_joyl          1
#define p_joyr          2
#define p_start         3
#define p_up            4
#define p_right         5
#define p_down          6
#define p_left          7
#define p_l2            8
#define p_r2            9
#define p_l1            10
#define p_r1            11
#define p_triangle      12
#define p_circle        13
#define p_cross         14
#define p_square        15
#define p_joy_lx        16
#define p_joy_ly        17
#define p_joy_rx        18
#define p_joy_ry        19
#define p_joy_lu        20
#define p_joy_ld        21
#define p_joy_ll        22
#define p_joy_lr        23
#define p_joy_ru        24
#define p_joy_rd        25
#define p_joy_rl        26
#define p_joy_rr        27

#define p_con_status    28
#define p_motor1        29
#define p_motor2        30
#define P_status        31

class Control_PS2{
public:
    /*
    *
    * Setup PS2 connection
    */
    void Setup();
    
    /*
    * return -1 = Disconnect
    * return  0 = Connected
    *
    * Start communication with PS2 controller
    *
    * 1 = TRIANGLE
    * 2 = SQUAIRE
    * 3 = CIRCLE
    * 4 = CROSS
    *
    * 5 = Joystick r_up
    * 6 = Joystick r_down
    * 7 = Joystick r_left
    * 8 = Joystick r_right   
    */
    int Connect(bool);

private:
    char buffer[16];
    
    Ticker inputError;
    btnValues btnPress;
    
    int a, b, c, time;
    bool bug;
    
    btnValues checkButton(char*);
    int checkJoyStick(char*,int);
    void solveProblem();
    
    
};

#endif
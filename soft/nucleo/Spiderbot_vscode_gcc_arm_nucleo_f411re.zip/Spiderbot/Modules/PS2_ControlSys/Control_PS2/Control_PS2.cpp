#include "Control_PS2.h"

 // (USBTX,USBRX);            
Serial _PS2(D8,D2);
Serial comp(USBTX,USBRX);
WalkOrient Controls;


void Control_PS2::Setup(){
    Controls.setup();
    comp.format(8, Serial::None, 1);
    comp.baud(9600);
    
    _PS2.format(8, Serial::None, 1);
    _PS2.baud(57600); 
    _PS2.printf("ae");
}

btnValues Control_PS2::checkButton(char *b){
    time = 0.15;//comp.printf("%s \n\r", b);  
    for(int i = 0; i <= 10; ++i){
         /*
        * figures
        */
        if((b[i] == 't') && (b[i + 1] == 'r')){
            btnPress.action = (p_triangle);
            break;    
        }
        else if((b[i] == 's') && (b[i + 1] == 'q')){
            btnPress.action = (p_square);
            break;    
        }
        else if((b[i] == 'c') && (b[i + 1] == 'i')){
            btnPress.action = (p_circle);
            break;    
        }
        else if((b[i] == 'c') && (b[i + 1] == 'r')){
            btnPress.action = (p_cross);
            break;   
        } 
        
         /*
        * arrows
        */
        else if((b[i] == 'u') && (b[i + 1] == 'p')){
            btnPress.action = (p_up); 
            break;   
        } 
        else if((b[i] == 'd') && (b[i + 1] == 'w')){
            btnPress.action = (p_down); 
            break;    
        } 
        else if((b[i] == 'l') && (b[i + 1] == 'f')){
            btnPress.action = (p_left); 
            break;    
        }
        else if((b[i] == 'r') && (b[i + 1] == 'g')){
            btnPress.action = (p_right); 
            break;    
        } 
        
         /*
        * action buttons
        */ 
        else if((b[i] == 'l') && (b[i + 1] == '1')){
            btnPress.action = (p_l1); 
            break;   
        } 
        else if((b[i] == 'l') && (b[i + 1] == '2')){
            btnPress.action = (p_l2);
            break;    
        }
        else if((b[i] == 'r') && (b[i + 1] == '1')){
            btnPress.action = (p_r1);
            break;   
        }
        else if((b[i] == 'r') && (b[i + 1] == '2')){
            btnPress.action = (p_r2);
            break;    
        }
        
         /*
        * select buttons
        */ 
        else if((b[i] == 's') && (b[i + 1] == 'e')){
            btnPress.action = (p_select);
            break;    
        }
        else if((b[i] == 's') && (b[i + 1] == 't')){
            btnPress.action = (p_start);  
            break;   
        }
        
         /*
        * joy-stick buttons
        */ 
        else if((b[i] == 'j') && (b[i + 1] == 'l')){
            btnPress.action = (p_joyl); 
            break;   
        }
        else if((b[i] == 'j') && (b[i + 1] == 'r')){
            btnPress.action = (p_joyr); 
            break;   
        }
        /*
        * joy-stick right
        */
        else if((b[i] == 'r') && (b[i + 1] == 'u')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_ru);
            wait(time);
            break;   
        }
        else if((b[i] == 'r') && (b[i + 1] == 'd')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_rd);
            wait(time);
            break;   
        }
        else if((b[i] == 'r') && (b[i + 1] == 'l')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_rl);
            wait(time);
            break;   
        }
        else if((b[i] == 'r') && (b[i + 1] == 'r')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_rr);
            wait(time);
            break;   
        }
        
        /*
        * joy-stick left
        */
        else if((b[i] == 'l') && (b[i + 1] == 'u')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_lu);
            wait(time);
            break;   
        }
        else if((b[i] == 'l') && (b[i + 1] == 'd')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_ld); 
            wait(time);
            break;   
        }
        else if((b[i] == 'l') && (b[i + 1] == 'l')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_ll);
            wait(time);
            break;   
        }
        else if((b[i] == 'l') && (b[i + 1] == 'r')){
            btnPress.value = checkJoyStick(b,(i+2));
            btnPress.action = (p_joy_lr);
            wait(time);
            break;   
        }
    }
    return btnPress;
}

int Control_PS2::checkJoyStick(char *jBuffer,int bufferVal){
        //joy stick value builder move this to a new function
        a = (jBuffer[bufferVal] - '0')*100;
        b = (jBuffer[bufferVal +1] - '0')* 10;
        c = (jBuffer[bufferVal +2] - '0');    
        
        return (a+b+c);
}

void Control_PS2::solveProblem(){
    if(bug){
        comp.printf("Input error \n\r");
        bug = false;
        for(int i = 0; i <=10;++i){
            buffer[i] = 0;
        }
    }
}

int Control_PS2::Connect(bool flag){
    char buffer[16];
   
    while((_PS2.getc() != '0') && (flag)){
        // creating a bug tester
        inputError.attach(this,&Control_PS2::solveProblem,5);
        
        for(int i = 0; i <= 10; ++i){
            buffer[i] = _PS2.getc();
            // a input bug can be created
            bug = true;
        }
        // destroying the bug tester
        inputError.detach();
        bug = false;
        
        btnPress = checkButton(buffer);
        Controls.startAction(&btnPress.action,btnPress.value);
    }; 
    
    return 0;
}
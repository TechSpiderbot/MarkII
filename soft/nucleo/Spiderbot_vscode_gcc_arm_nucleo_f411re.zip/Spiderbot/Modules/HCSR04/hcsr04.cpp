#include "hcsr04.h"
#include "mbed.h"
/*
*HCSR04.cpp
*/
HCSR04::HCSR04(PinName t, PinName e) : trig(t), echo(e) {}
 long HCSR04::echo_correction(){
    timer.reset();                                                              // measure actual software polling timer delays                                                                            // delay used later in time correction                                    
    timer.start();                                                              // start timer
    while (echo==2) {};                                                         // min software polling delay to read echo pin
    timer.stop();                                                               // stop timer
                                                   
    return timer.read_us();                                                     // read timer
}

 long HCSR04::echo_duration() {   
    timer.reset();
    trig = 0;                                                                   // trigger low 
    wait_us(2);                                                                 //  wait 
    trig = 1;                                                                   //  trigger high
    wait_us(10);
    trig = 0;                                                                   // trigger low
    while(echo == 0){};                                                               // start pulseIN
    timer.start();
    while(echo == 1){};
    timer.stop();
    
    return timer.read_us(); 
 
}
 
//return distance in cm 
long HCSR04::distance(){
    correction = echo_correction();
    duration = echo_duration();
    distance_cm = (duration - correction) / 58.0 ;
    
    return distance_cm;

}
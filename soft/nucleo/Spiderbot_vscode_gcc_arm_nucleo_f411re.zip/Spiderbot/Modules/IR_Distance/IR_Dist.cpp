#include "IR_Dist.h"
#include "mbed.h"
/*
*IR_Dist.cpp
*/
IR_Dist::IR_Dist(PinName a) : IRSens(a){}

 float IR_Dist::Equation() {   
    volts = IRSens.read_u16()* 0.02441406;                                      // 5v / 2048 = 0.02441406
     
    return 5034.2 * pow(volts,-0.959);                                          // x = 5034.2x-0.959
}
 
//return distance in cm 
float IR_Dist::distance(){
    correction = 1;
    som = Equation();
    distance_cm = (som - correction);
    
    return distance_cm;

}
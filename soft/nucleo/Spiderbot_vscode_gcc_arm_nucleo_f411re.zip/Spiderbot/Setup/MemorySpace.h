#ifndef MBED_MemorySpace_H
#define MBED_MemorySpace_H

/*
*   The maximum used Servos in the whole robot: 13
*   address consist of: [ID number] [address] [servoType]
*
*   Servo Types:
*   RS-2    = TOO   :1
*   MG90S   = HIP   :2
*   MG996R  = ARM   :3
*
*/

#define maxServoID  13
#define address      5
#define maxServoFlag 1
#define flag1        0

#define RS2          1 
#define MG90S        2
#define MG996R       3 

/*
*   Address Setup 
*
*   The addresses for each servo 
*   [ID number] [address] [servoType] [location in memory]
*
*   ID number   =   following number
*   Address     =   pcb connection number
*   ServoType   =   connected servomotor
*   location in memory = given location in storedData
* 
*/

#define _IDnumber    0
#define _address     1
#define _servoType   2
#define _row         3
#define _column      4
    
extern int addressPlace[maxServoID][address];

/*
* Defined values for error msg.
*
*   _error  = ERROR FLAG
*   _nerror = NO ERROR FLAG
*/
#define _error      1
#define _nerror     0

/*
*   maxUnits are bodyparts that rotate synchronic with the body
*   Units:
*   -Leg Back Left
*   -Leg Front Left
*   -Leg Back Right    
*   -Leg Front Right
*   -Container
*
*   storedData [ID number] [HIP] [ARM] [TOO] [ERROR Flag]
    
    Last Position    |  ~leg(0)    |   ~hip(1)      |  ~Arm(2)  |   ~Too(3) |   ~Arm(4)     |   ~Too(5)     |   ~flag(6)    |
                     |  ID number  |   rotation     |  rotation |  rotation |   Height      |   Distance    |   msg         |
    =========================================================================================================================
    left back     (0)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |
    left front    (1)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    | 
    right back    (2)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |  
    right front   (3)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |  
    container     (4)|  ~ID num    |  ~degrees      |           |           |               |               |   ~_nerror    |
  
    
    New position     |  ~leg(0)    |   ~hip(1)      |  ~Arm(2)  |   ~Too(3) |   ~Arm(4)     |   ~Too(5)     |   ~flag(6)    |
                     |  ID number  |   rotation     |  rotation |  rotation |   Height      |   Distance    |   msg         |
    =========================================================================================================================
    left back     (0)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |               |               |   ~_nerror    |
    left front    (1)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |               |               |   ~_nerror    | 
    right back    (2)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |               |               |   ~_nerror    |  
    right front   (3)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |               |               |   ~_nerror    |  
    container     (4)|  ~ID num    |  ~degrees      |           |           |               |               |   ~_nerror    |
 
    
*/

#define maxUnits    5
#define storedData  7

struct MemorySpace{    
  int lastPosition[maxUnits][storedData];
  int newPosition[maxUnits][storedData];
  
  int addressFlags[maxServoID][maxServoFlag];
};

#endif
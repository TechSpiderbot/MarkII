#ifndef MBED_setup_H
#define MBED_setup_H

#define DEBUG
#define MODULE_DEBUG
#define DISPLAY

//--servodriver ****************************************************************
#include "mbed.h"
#include <string>
#include "Serial.h"
#include "Adafruit_PWMServoDriver.h"
//#include "BMP180.h"

#include "TextLCD.h"
#include "Control_PS2.h"
#include "hcsr04.h"
#include "IR_Dist.h"

#define SLAVE_ADDR 0x12 // >>> 0x09
#define COMPASS_ADDR 0x10 // >>> 0x08


class setup{
public:

    void Scanner();
    /*
    * @ Type servo (1 = RS-2, 2 = MG90S, 3 = MG996R)
    * @ Adress value between(0-15)
    * @ Duty value between(0-180)
    * Setup servomotors
    */
    void SetupServo(bool);
    
    void position(int,int,int);
    
    void spiderActivate();
    
    /*
    *
    * Setup baromoter
    */
/*
    void SetupBaroM();
    
    int ReadTemperture(float *tempC);  
    
    void creatOffsetBaro();
    
    int ReadHeight(float *heightM);
*/
    
    /*
    *
    * Setup Gyroscoop
    */   
    
 
    int SetupGyroM(bool);
    
    int readGyroData(bool,bool,bool);
    
    void Rx_interrupt(int &number,int setup);
    
      
    //void ReadPichRoll(float &Pitch,float &Roll){ mpu6050.complementaryFilter(&Roll,&Pitch); }
    //void initGyro(){ mpu6050.init(); }
    //void calibrateGyro(float &dest1,float &dest2){ mpu6050.calibrate(&dest1,&dest2); }
    //void wakeupGyro(bool flag){ mpu6050.setSleepMode(flag); }
    
    
    
    /*
    *
    * Setup Display
    */
    
    void SetupDisplay(bool);
    
    void ScrollMenuDisplay(char[],char[]);
    
    
    /*
    *
    * Setup PS2 Controller
    */
    void SetupPS2(bool);
    
    void ConnectPS2();
    
    /*
    *
    * Setup Sonar
    */
    void SetupSonar(bool);
    
    int ReadSonar(long *distance);
    
    /*
    *
    * Setup IR sensor
    */
    void SetupIRSens(bool);
    int Read_IRSens(float *distance);
    
    //long clock_ms(){ return us_ticker_read() / 1000; }
    char readI2C(int address);
    
    /*
    *
    * Setup Server connection
    *
    * sendToServer(char dataMessage[], int Length) 
    */
    
    void sendToServer(char[],int);
    
    /*
    *
    * Setup Compass
    */
    void ackCalibrateCompas();
    void requestCompass(char &direction);

private:
    //Setup baromoter
    static float DelayServoSetting;
    //MPU6050 mpu6050; 
    int fb,y,pressure;
    int offsetBaro;
    
    // Setup uart
    float temp, dest1,dest2, _pitch, _roll;   
    char buffer[255];
    
    char distance[3];
};
#endif
#include "setup.h"

//******************************************************************************
Serial pc(USBTX,USBRX);                                                         // USB to computer
Serial gyroUART(PA_11,PA_12);                                                   // adruino nano > gyro UART_TX,UART_RX

I2C i2c(D14,D15);                                                               // I2C bus,
                                                                                
Adafruit_PWMServoDriver pwm(D14,D15);                                           // I2C bus, PWM-Driver D14,D15
TextLCD_I2C lcd(&i2c, 0x4E, TextLCD::LCD16x2, TextLCD::HD44780);                // I2C bus, PCF8574 Slaveaddress, LCD Type

//D12 TRIGGER D11 ECHO
HCSR04 Sonar1(D10, D11);
//A0 Analoogin
IR_Dist IRSense(A0); 

Control_PS2 PS2Control;

//******************************************************************************
void setup::Scanner(){
    pc.printf("SCANNING...\r\n");
    for(int i = 0; i < 128 ; i++) {
        i2c.start();
        if(i2c.write(i << 1)) pc.printf("0x%x ACK \r\n",i); // Send command string
        i2c.stop();
    }
    pc.printf("FINISHED!\r\n");
}

//******************************************************************************
void setup::SetupServo(bool bServoActivated){
    #ifdef DISPLAY

    #endif
    
    if(bServoActivated){
        #ifdef DEBUG
        pc.printf("Initialized Servo\n\r");
        #endif
        
        pwm.begin();
        pwm.reset();
        pwm.setPWMFreq(50);
        pwm.setPrescale(80);    //RS2 = 64 
        pwm.setI2Cfreq(400000); //400kHz fast I2C comunication
    
        pwm.setPWM(0,560,3400);  // Left Back Too
        pwm.setPWM(1,560,3400);  // Left Back Arm
        pwm.setPWM(2,560,3400);  // Left Back Hip
        pwm.setPWM(3,560,3400);  // Left Front Too
        pwm.setPWM(4,560,3400);  // Left Front Arm
        pwm.setPWM(5,560,3400);  // Left Front Hip
        pwm.setPWM(6,560,3400);  // Back Body
        pwm.setPWM(7,560,3400);  // top Lidar
        pwm.setPWM(8,560,3400);  // NONE
        pwm.setPWM(9,560,3400);  // NONE
        pwm.setPWM(10,560,3400); // Right Front Hip
        pwm.setPWM(11,560,3400); // Right Front Arm
        pwm.setPWM(12,560,3400); // Right Front Too
        pwm.setPWM(13,560,3400); // Right Back Hip
        pwm.setPWM(14,560,3400); // Right Back Arm
        pwm.setPWM(15,560,3400); // Right Back Too
        
        spiderActivate();
    }
    else{
        #ifdef DEBUG
        pc.printf("SERVO OFF\n\r");
        #endif
        
        #ifdef DISPLAY
        // clear screen
        
        // servo OFF
        
        #endif
    }
}

//******************************************************************************
void setup::position(int type,int adress,int duty){
    //int y = ((9.3968* duty) + 560);
    switch(type){
        case 1:
            y = ((8.6742* duty) + 543.65);  //RS-2 servo
            break;
        case 2:
            y = ((9.2178* duty) + 382.3); //MG90S servo
            break;
        case 3:
            y = ((7.11111* duty) + 531.97); //MG996R servo
            break;
    }
    pwm.setDuty(adress,y);  
} 

float setup::DelayServoSetting = 0.5f;

void setup::spiderActivate(){
    #ifdef DEBUG
    pc.printf("SPIDER ACTIVE\n\r");
    #endif
    
    #ifdef DISPLAY
    // servo ON
    
    #endif
    
    // type, address, duty
    // container up
    position(2,6,1);                                                           // Container
    //Set.position(2,7,90);                                                    // Lidar
    //Set.position(2,8,90);                                                    // NONE
    //Set.position(2,9,90);                                                    // NONE
    wait(DelayServoSetting + 0.5f);
    
    position(3,1,170);                                                         // Left Back Arm
    wait(DelayServoSetting); 
    position(1,0,140);                                                         // Left Back Too
    
    position(3,14,170);                                                        // Right Back Arm
    wait(DelayServoSetting);
    position(1,15,140);                                                        // Right Back Too
                                                            
    position(3,11,170);                                                        // Right Front Arm
    wait(DelayServoSetting);  
    position(1,12,140);                                                        // Right Front Too
    wait(DelayServoSetting);
    
    position(3,4,170);                                                         // Left Front Arm
    wait(DelayServoSetting);
    position(1,3,140);                                                         // Left Front Too
    
    position(2,2,60);                                                          // Left Back Hip
    position(2,13,120);                                                         // Right Back Hip
    position(2,10,90);                                                         // Right Front Hip
    position(2,5,90);                                                          // Left Front Hip
    wait(DelayServoSetting + 1.5f);
           
    wait(DelayServoSetting);
    position(3,1,130);                                                         // Left Back Arm
    position(3,4,130);                                                         // Left Front Arm
    position(3,11,130);                                                        // Right Front Arm
    position(3,14,130);                                                        // Right Back Arm 
    wait(3);
}

//******************************************************************************


int setup::SetupGyroM(bool bGyroMActivated){
    
    #ifdef DEBUG
    pc.printf("Initialized GyroM\n\r");
    #endif
        
    #ifdef DISPLAY
    // clear display
    //HMI.clear();
    // init gyrometer
    //HMI.print("INIT GYROM\n");
    #endif
    
    gyroUART.baud(115200);  
    // Setup a serial interrupt function to receive data
    //gyroUART.attach(this, &setup::Rx_interrupt, Serial::RxIrq);
           
    if(bGyroMActivated){ 
        int num = 0;      
        
        gyroUART.printf("ack\n");
        Rx_interrupt(num,1);    // receive num, 1 = setup/ 0 = data
        
        return 0;
     }
     else{
        gyroUART.printf("dis\n");
        
        #ifdef DEBUG
        pc.printf("GYRO OFF \n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("DISABLE GYRO\n");
        //wait(0.5);
        #endif
        
        return 1;
    }
}

int setup::readGyroData(bool yaw,bool pitch,bool roll){
    int num = 0;
    
    if(yaw){
        gyroUART.printf("i\n");
        Rx_interrupt(num,0);                                                    
    }
    
    if(pitch){
        gyroUART.printf("j\n");
        Rx_interrupt(num,0);                                                    
    }
    
    if(roll){
        gyroUART.printf("k\n");
        Rx_interrupt(num,0);                                                    
    }
    
    #ifdef DEBUG
    pc.printf("nr: %i \n\r", num);
    #endif
    
    return num;
}
void setup::Rx_interrupt(int &number,int setup){
    number = 0;
    int i = 0;
    char c = 0;
    int length = 0;
    // Loop just in case more than one character is in UART's receive FIFO buffer
    // Stop if buffer full
    while(!gyroUART.readable()){}
    
    // read raw data
    while(c != '\n'){    
        c = gyroUART.getc();
        buffer[i++] = c;
        if(c == '\n'){
            break;
        }
    }
    
    // delete last char
    if(c == '\n'){
        buffer[i - 1] = 0;
    } 
    
    // convert string to data
    for(int i = 0; i <= 32; i++){
        if(buffer[i] == 13){ 
            break;
        }
        buffer[i] = buffer[i] - '0';
        length++;  
    }
    
    #ifdef DEBUG
    pc.printf("length: %i \n\r", length);
    #endif
    
    //convert data into a value
    if(length == 1){
        number = buffer[0];
    }
    else if(length == 2){
        for(int i = 0; i <= length; i++){ 
            if(i == 0){
                buffer[i] *= 10;  
            }
        }
        number = buffer[0] + buffer[1];
    }
    else if(length == 3){
        for(int i =0; i <= length; i++){ 
            if(i == 0){buffer[i] *= 100;}
            if(i == 1){buffer[i] *= 10;}  
        }
         number = buffer[0] + buffer[1] + buffer[2];   
    }
    
    
    if(setup == 0){
        number -= 90;
    }
    
    return;
}
    

//******************************************************************************

//******************************************************************************
void setup::SetupDisplay(bool bDisplayActivated){
    if(bDisplayActivated){
        #ifdef DEBUG
        pc.printf("Initialized Display\n\r");
        #endif
        
        lcd.cls();  
        lcd.setBacklight(TextLCD::LightOn);
        // Show start text 
        lcd.printf("----START-UP----");
    }
    else{
        lcd.cls();
        
        #ifdef DEBUG
        pc.printf("DISPLAY OFF \n\r");
        #endif
    }                   
}

// get reworked

void setup::ScrollMenuDisplay(char string1[], char string2[]){ 
    lcd.cls(); // clear LCD
    // if text failed to write ( send 3 times)
    for(int i=0; i < 3; i++){
        lcd.setAddress(0,0); // set cursor on the second row
        lcd.printf(string1);
        lcd.setAddress(0,1);
        lcd.printf(string2);
            
    }    
}

//******************************************************************************
void setup::SetupPS2(bool bPS2Activated){    
    if(bPS2Activated){
        #ifdef DEBUG
        pc.printf("Initialized PS2_Controller \n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("INIT PS2 \n");
        //wait(0.5);
        #endif
        
        PS2Control.Setup();
    }
    else{
        #ifdef DEBUG
        pc.printf("PS2 Initialization Error \n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("ERR PS2 \n");
        //wait(0.5);
        #endif
    }
}

//******************************************************************************
void setup::ConnectPS2(){
    #ifdef MODULE_DEBUG
    pc.printf("Connect PS2Control.. \n\r");
    #endif
    
    #ifdef DISPLAY
    //lcd.printf("CON.. PS2 \n");
    //wait(0.5);
    #endif
    
    PS2Control.Connect(true);
}

//******************************************************************************
void setup::SetupSonar(bool bSonarActivated){
    if(bSonarActivated){
        #ifdef DEBUG
        pc.printf("Initialized Sonar\n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("INIT SONAR \n");
        //wait(0.5);
        #endif
        
        // EMPTY
    }
    else{
        #ifdef DEBUG
        pc.printf("Sonar Initialization Error \n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("ERR SONAR \n");
        //wait(0.5);
        #endif
    }
}

int setup::ReadSonar(long *distance){
    *distance = Sonar1.distance();
    return 0;
}

//******************************************************************************
void setup::SetupIRSens(bool bIRSensActivated){
     if(bIRSensActivated){
        #ifdef DEBUG
        pc.printf("Initialized IRSens\n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("INIT IRSENS \n");
        //wait(0.5);
        #endif
        
        // EMPTY
    }
    else{
        #ifdef DEBUG
        pc.printf("IRSens Initialization Error \n\r");
        #endif
        
        #ifdef DISPLAY
        //lcd.printf("ERR IRSENS \n");
        //wait(0.5);
        #endif
    }
}

int setup::Read_IRSens(float *distance){
    *distance = IRSense.distance();
    return 0;
}

//******************************************************************************

char setup::readI2C(int address){
    // Define a variable to hold byte of data

    char bval;
    
    i2c.read(address, &bval, 1);   //Open device in read mode, read 1 byte. 
    return bval;
}

//******************************************************************************  
void setup::sendToServer(char dataMessage[], int Length){   
    // **Send hello World to arduino test**
    i2c.write(SLAVE_ADDR,dataMessage,Length); 
}

//******************************************************************************
void setup::ackCalibrateCompas(){
    char dataMessage[] = "h";
    
    i2c.write(COMPASS_ADDR,dataMessage,sizeof(dataMessage));    // send h
}

void setup::requestCompass(char &direction){
    i2c.write(COMPASS_ADDR,0,1);    // send 0
    i2c.read(COMPASS_ADDR, &direction, 1);
}

//******************************************************************************

/*
void setup::SetupBaroM() {    
    while(1){
        if (bmp180.init() != 0){
            pc.printf("Error communicating with BMP180\n\r");
        } else{
            pc.printf("Initialized BMP180\n\r");
            break;
        }
        wait(1);
    }

    bmp180.startTemperature();
    wait_ms(5);     // Wait for conversion to complete
    if(bmp180.getTemperature(&temp) != 0) {
        pc.printf("Error getting temperature\n\r");
    }
    
    bmp180.startPressure(BMP180::ULTRA_HIGH_RESOLUTION);
    wait_ms(10);    // Wait for conversion to complete
    if(bmp180.getPressure(&pressure) != 0) {
        pc.printf("Error getting pressure\n\r");
    }
    
    // reading offset value
    offsetBaro = bmp180.getPressure(&pressure);
    
    pc.printf("Calibration BMP180 complete\n\r");
}

//******************************************************************************
int setup::ReadTemperture(float *tempC){
    bmp180.startTemperature();
    wait_ms(5);    // Wait for conversion to complete
    bmp180.getTemperature(&temp);
    
    *tempC = temp;
    
    return 0;
}

//******************************************************************************
void setup::creatOffsetBaro(){
    bmp180.startPressure(BMP180::ULTRA_HIGH_RESOLUTION);
    wait_ms(10);    // Wait for conversion to complete
    bmp180.getPressure(&pressure);
    
    offsetBaro = ((31.307 * pressure) + 99287) *0.0001;
    
    pc.printf("Create offset %i \n\r",offsetBaro);
}

//******************************************************************************
int setup::ReadHeight(float *heightM){
    float _total = 0;
    int _buffer = 50;
    int _samples[_buffer];
    
    for(int i = 0; i <= (_buffer -1); ++i){
        bmp180.startPressure(BMP180::ULTRA_HIGH_RESOLUTION);
        wait_ms(10);    // Wait for conversion to complete
        bmp180.getPressure(&pressure);
        _samples[i] = pressure;
    }
    
    for(int i = 0;i <= (_buffer -1);i++){
        _total += _samples[i]; 
    }
    
    pressure = (_total / _buffer);
    pc.printf("pressure %i \n\r",pressure);
    
    float x = ((31.307 * pressure) + 99287) *0.0001;
    x = (x - offsetBaro);
    *heightM = x;
    
    return 0;
}
*/

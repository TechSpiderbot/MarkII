#include "main.h"
Serial link(USBTX,USBRX); 
Kinematics kinemat; 
MemorySpace _mem;
NeuroNetwork NeuroNet;

DRV8833 Container(D6,D5,D7,D9);                                                 // container(pwm1,pwm2,sleep,homeSwitch)

setup Set;
Ticker tickRead;
//buttons setting 
Timer debounce; 
Timer t;   // timer
InterruptIn ControlBtn1(D4);
InterruptIn ControlBtn2(D3);

States CurrentState;

void setup(){
    
    // create serial comunication protocol
    link.format(8, Serial::None, 1);
    link.baud(9600);  
    
    //Set.Scanner();
    //Setup Display
    Set.SetupDisplay(true);                                                                                                         
    //Set.SetupServo(true);  
    //Set.SetupGyroM(true); 
                                                     
/*   
    Set.SetupPS2(false);                                                           
    Set.SetupSonar(false);                                                         
    Set.SetupIRSens(false);                                                    
*/  
    // ceate memory setup 
    //kinemat.SetupMemory(_mem);
}

void Inter_btn1();
void Inter_btn2();
void ContrlBtn(int);
void inputAction(int,int &currentScreen);
void printScreen(States &CurrentState, int &currentScreen);
string IntToString(int a);
void readGyro();
void TestScript();

int main(){
    setup();
    #ifdef DEBUG   
    link.printf("\n\r");
    link.printf("Init Setup \n\r");
    #endif   
    //TestScript();

    // values IR sensor
//    float IR_Distance;


// scroll menu states
    
    CurrentState = MAIN;
    int currentScreen = 0;
    int currentMainScreen = 0;
    int currentModuleScreen = 0;
     //buttons 
    ControlBtn1.rise(&Inter_btn1);                                                   
    ControlBtn2.rise(&Inter_btn2);
    
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
   
    //ContainerHomeSwitch.mode(PullUp);
    
    /*
        Neuronetwork implementation
    */
    
/*    
    if(ERROR_FLAG == 0){   
        NeuroNet.stabilisationRun(false);
    }
*/
    //TestScript();

    #ifdef DEBUG
    link.printf("Main loop: Activation \n\r");
    #endif
     
        Container.home();           // speed -1 = 12sec to full
    
        Container.wakeup(true); 
        Container.speed(-1);
        wait(6);
        Container.brake(BRAKE);
        Container.wakeup(false);
        
    
    while(true){ 
    // when the button is pressed find new state 
        if(buttonPressed == true){
            buttonPressed =  false;
            
            switch(CurrentState) {
                case MAIN:
                   // inputAction(number Of Screens, current screen)
                    inputAction(numOfMainScreens,currentMainScreen);
                    printScreen(CurrentState,currentMainScreen); 
                    
                    if(Bbtn1 && (currentMainScreen == numOfMainScreens - 3)){   // if longPress Btn1 on MODULES then enter>>
                        CurrentState = MODULES;                                 // change State
                        currentScreen = currentModuleScreen;                    // change current screen
                    }
                    else{
                        currentScreen = currentMainScreen;                      
                    }
                    break;
                case SETTINGS:
                    break;
                case MODULES:
                    // inputAction(number Of Screens, current screen)
                    inputAction(numOfModulesScreens,currentModuleScreen);
                    printScreen(CurrentState,currentModuleScreen);
                    
                    if(Bbtn1 && (currentModuleScreen == numOfModulesScreens -1)){
                        CurrentState = MAIN;
                        currentScreen = currentMainScreen;
                    }
                    else{
                        currentScreen = currentModuleScreen;
                    }
                    break;
                case STATE:
                    break;
                case EXIT:
                    break;
            }
            
            // reset buttons
            if(Bbtn1){
                Bbtn1 =! Bbtn1;
            }
            else if(Bbtn2){
                Bbtn2 =! Bbtn2;
            } 
            wait_ms(500); // activation on screen visible
        }
        // update screen info
        printScreen(CurrentState,currentScreen);
        wait(1);
    }   
}

//******************************************************************************
string IntToString(int a){
    ostringstream temp;
    temp << a;
    return temp.str();
}
// settings for printing data on the lcd screen
void printScreen(States &CurrentState, int &currentScreen){
    string empty = "\n";
    char charString1[16] = {0};
    char charString2[16] = {0};
    
    long SonarDistance;
    string s;
    
    switch(CurrentState){
        case MAIN:
            strcpy(charString1,Main_screen[currentScreen][0].c_str());
            
            if(Bbtn1){
                strcpy(charString2,Main_screen[currentScreen][1].c_str());
            }
            else{ strcpy(charString2,empty.c_str()); } 
            break;
        case MODULES:
            strcpy(charString1,MODULES_screen[currentScreen][0].c_str());
            if(currentScreen == 1){ // Cont-Sonar
                Set.ReadSonar(&SonarDistance);
                s = IntToString(SonarDistance) + "cm\n";
                strcpy(charString2,s.c_str());
            }
            else{
                strcpy(charString2,MODULES_screen[currentScreen][1].c_str());
            }
            break; 
    }
 
    
    Set.ScrollMenuDisplay(charString1,charString2);
}

//******************************************************************************
// Agents that controls how to scroll through the menu
void inputAction(int numOfScreens, int &currentScreen){
    if((pressedShort) && (buttonNumb == 1)){
        if(currentScreen == numOfScreens -1){
            currentScreen = 0;
        }
        else{ currentScreen++;}
    }
    
    if((pressedShort) && (buttonNumb == 2)){
        if(currentScreen == 0){
            currentScreen = numOfScreens -1;
        }
        else{ currentScreen--;}
    }
    
    if((pressedLong == true) && (buttonNumb == 1)){
        Bbtn1 =! Bbtn1;
    }
    
    if((pressedLong == true) && (buttonNumb == 2)){
        Bbtn2 =! Bbtn2;
    }  
}

//#BUTTON 1 
void Inter_btn1(){   
    ContrlBtn(1);                                                            
}

//#BUTTON 2
void Inter_btn2(){  
    ContrlBtn(2);                                                                
}

// Detection of a long oand short press on a button
void ContrlBtn(int i){
    int pushBtn;
    pushBtn = 0;
    
__disable_irq();                                                                 
    debounce.start();
    // only allow toggleif debounce timer
    if(debounce.read_ms()> 200){                                       
        buttonPressed = true; 
        t.reset(); 
        
        // timer to detect the long press
        wait(0.1);                                                              
        // while button is idle >> niks
        if(i == 1){
            while(ControlBtn1 == 0) {};}
        else if(i == 2){
            while(ControlBtn2 == 0) {};}
            
        // start timer
        t.start(); 
        // while button is pressed >> count time
        if(i == 1){
            while(ControlBtn1 == 1) {};}
        else if(i == 2){
            while(ControlBtn2 == 1) {};}
       
        // stop timer
        t.stop(); 
        // read timer
        pushBtn = (t.read_ms()); 
        
        if((pushBtn >= 800) && ((i == 2) || (i == 1))){ 
            pressedShort = false;
            pressedLong = true;
            buttonNumb = i;
        }
        else if((pushBtn < 800) && ((i == 2) || (i == 1))){ 
            pressedShort = true;
            pressedLong = false;
            buttonNumb = i;
        }           
    }
    debounce.reset();  
__enable_irq();        
}
//******************************************************************************

// ======================== TESTS===============
/* Send "hello world" to PiServer
    while(1){
        char text[] = "Hello World!";
        Set.sendToServer(text,sizeof(text));
        wait(1);
    }
*/
    
/* read compass direction
    
    char direction;
    Set.ackCalibrateCompas();
    while(1){
        Set.requestCompass(direction);
        link.printf("%i \n\r",direction);
        wait(1);
    }
*/

/* Move Container up and down
    //ContainerWakeUp = true;
    //Container.period(0.01); 
    //Container.speed(-0.5);
    //wait(5);
    //Container.brake(BRAKE);
    //ContainerWakeUp = false;
*/

/* sonar
    Set.ReadSonar(&SonarDistance);
    link.printf("distanca %d cm \n\r",SonarDistance);
    wait(1);
*/  

/* IR-sensor
    Set.Read_IRSens(&IR_Distance);
    link.printf("distance %2.0f \n\r",IR_Distance);
    wait(1);
 */   
        
//PS2 controller            
    //Set.ConnectPS2();
    
// TestScript: shows Memory setup
void TestScript(){
    int space = 5;
    /*
    * ==TEST
    */ 
    
    #ifdef DEBUG    
    link.printf("Init TEST\n\r");
    #endif
            
        /*
        *   show SetupMemory: 
        *   - lastPosition
        *   - newPosition
        *   - addressFlags
        */
        
        /*
            Last Position    |  ~leg(0)    |   ~hip(1)      |  ~Arm(2)  |   ~Too(3) |   ~Arm(4)     |   ~Too(5)     |   ~flag(6)    |
                             |  ID number  |   rotation     |  rotation |  rotation |   Height      |   Distance    |   msg         |
            =========================================================================================================================
            left back     (0)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |
            left front    (1)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    | 
            right back    (2)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |  
            right front   (3)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |  
            container     (4)|  ~ID num    |  ~degrees      |           |           |               |               |   ~_nerror    |
        */
        link.printf("= Last Position::[]\n\r");
        
        link.printf("[%*s] [%*s] [%*s] [%*s] [%*s] [%*s] [%*s] [%*s] \n\r",space,"",space,"ID",space,"hip",space,"arm",space,"too",space,"arm",space,"too",space,"flag");

        for(int i = 0; i < maxUnits; i++){
            link.printf("[%*i] ",space,i);
            for(int j = 0; j < storedData; j++){
                link.printf("[%*i] ",space,_mem.lastPosition[i][j]);
            }
            link.printf("\n\r");
        }
        
        /*
    
            New position     |  ~leg(0)    |   ~hip(1)      |  ~Arm(2)  |   ~Too(3) |   ~Arm(4)     |   ~Too(5)     |   ~flag(6)    |
                             |  ID number  |   rotation     |  rotation |  rotation |   Height      |   Distance    |   msg         |
            =========================================================================================================================
            left back     (0)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |
            left front    (1)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    | 
            right back    (2)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |  
            right front   (3)|  ~ID num    |  ~degrees      |  ~degrees |  ~degrees |   ~height     |   ~distance   |   ~_nerror    |  
            container     (4)|  ~ID num    |  ~degrees      |           |           |               |               |   ~_nerror    |
        */
        link.printf("= New Position::[]\n\r");
        
        link.printf("[%*s] [%*s] [%*s] [%*s] [%*s] [%*s] [%*s] [%*s] \n\r",space,"",space,"ID",space,"hip",space,"arm",space,"too",space,"arm",space,"too",space,"flag");
        
        for(int i = 0; i < maxUnits; i++){
            link.printf("[%*i] ",space,i);
            for(int j = 0; j < storedData; j++){
                link.printf("[%*i] ",space,_mem.newPosition[i][j]);
            }
            link.printf("\n\r");
        }
        
        /*
            addressFlags
            
            {1 ,flag} // Left Back ARM   
            {2 ,flag} // Left Back TOO
            {3 ,flag} // Left Front ARM
            {4 ,flag} // Left Front TOO
            {5 ,flag} // Right Back ARM
            {6 ,flag} // Right Back TOO
            {7 ,flag} // Right Front ARM
            {8 ,flag} // Right Front TOO
            {9 ,flag} // Left Back HIPS
            {10,flag} // Left Front HIPS
            {11,flag} // Right Back HIPS
            {12,flag} // Right Front HIPS
            {13,flag} // Container
        */

        link.printf("= addressFlags::[]\n\r");
        
        for(int i = 0; i < maxServoID; i++){
            for(int j = 0; j < maxServoFlag; j++){
                link.printf("nr: %*i [%*i] ",2,i,5,_mem.addressFlags[i][j]);
            }
            link.printf("\n\r");
        }

    #ifdef DEBUG    
    link.printf("TEST Complete \n\r");
    #endif
    
    /*
    * ==End test
    */
}
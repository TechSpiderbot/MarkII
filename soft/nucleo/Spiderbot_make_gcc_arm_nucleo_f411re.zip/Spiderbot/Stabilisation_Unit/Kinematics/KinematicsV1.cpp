#include "KinematicsV1.h"

Serial pc9(USBTX,USBRX);
setup SetServo;

int addressPlace[maxServoID][address]= 
    {
        //[ID number] [address] [servoType] [location in memory]
        {1,1,MG996R, 0,2}, // Left Back ARM   
        {2,0,RS2,    0,3}, // Left Back TOO
        {3,4,MG996R, 1,2}, // Left Front ARM
        {4,3,RS2,    1,3}, // Left Front TOO
        {5,14,MG996R,2,2}, // Right Back ARM
        {6,15,RS2,   2,3}, // Right Back TOO
        {7,11,MG996R,3,2}, // Right Front ARM
        {8,12,RS2,   3,3}, // Right Front TOO
        {9,2,MG90S,  0,1}, // Left Back HIPS
        {10,5,MG90S, 1,1}, // Left Front HIPS
        {11,13,MG90S,2,1}, // Right Back HIPS
        {12,10,MG90S,3,1}, // Right Front HIPS
        {13,6,MG996R,4,1}  // Container
    };


void Kinematics::SetupMemory(MemorySpace &mem){ 
    for(int i = 0; i < maxServoID; i++){
        mem.addressFlags[i][0] = _nerror;
    } // reset all addressFlags    
    
    for(int i = 1; i <= maxUnits; i++){
        mem.lastPosition[i-1][0] = (i * 10);
        mem.newPosition[i-1][0] = (i * 10);
    } //set unit ID number
    
    /*  &Last:
    *   -- unit: HIP storage
    */ 
    mem.lastPosition[0][storeHip] = 60;
    mem.lastPosition[1][storeHip] = 90;
    mem.lastPosition[2][storeHip] = 120;
    mem.lastPosition[3][storeHip] = 90;
    
    //  -- unit: Container storage
    mem.lastPosition[4][storeHip] = 1;
    
    //  -- unit: ARM : TOO : ERROR Flag storage
    for(int i = 0; i < (maxUnits - 1); i++){
        mem.lastPosition[i][storeArm] = 130;
        mem.lastPosition[i][storeToo] = 140; 
        mem.lastPosition[i][storeHeight] = 60;
        mem.lastPosition[i][storDistance] = 75; 
        mem.lastPosition[i][storeErr] = _nerror;      
    }
    
    /*  &New:
    *   --unit: Hip storage
    */ 
    mem.newPosition[0][storeHip] = 70;
    mem.newPosition[1][storeHip] = 100;
    mem.newPosition[2][storeHip] = 130;
    mem.newPosition[3][storeHip] = 100;
    
    //  -- unit: Container storage
    mem.newPosition[4][storeHip] = 1;
    
    //  -- unit: ARM : TOO : ERROR Flag storage
    for(int i = 0; i < (maxUnits - 1); i++){
        mem.newPosition[i][storeArm] = 130;
        mem.newPosition[i][storeToo] = 140;  
        mem.newPosition[i][storeErr] = _nerror;      
    }
} // Setup

void Kinematics::storeErrorMsg(int &ID,MemorySpace &cpyMem){
    int j;    
    for(int i = 1; i <= maxUnits; i++){
        j = (i * 10);
        if(ID == j){
            cpyMem.newPosition[(i - 1)][storeErr] = _error;     
        }
    } 
} // error msg

void Kinematics::storeHeightDistance(int &ID,MemorySpace &cpyMem,int &height, int &distance){
    int j;    
    for(int i = 1; i <= maxUnits; i++){
        j = (i * 10);
        if(ID == j){
            cpyMem.lastPosition[(i - 1)][storeHeight] = height;  
            cpyMem.lastPosition[(i - 1)][storDistance] = distance;   
        }
    }
} // store Height  and Distance

void Kinematics::checkCalculation(int &ID,MemorySpace &cpyMem,int &rotation,float &A,float &B){
    if( (A > 180) || (A < 0) || (B > 180) || (B < 0)){                                        
        if(A > 180){
            A = 180;
        }
        else if(A < 0){
            A = 0;
        }
        else if(B > 180){
            B = 180;
        }
        else if(B < 0){
            B = 0;
        }
            
        storeErrorMsg(ID,cpyMem); 
    } // rotation arm & too check
        
    if(rotation >= 180){                                    
        rotation = 180;
    }
    else if(rotation <= 0){
        rotation = 0; 
    } // Rotation hip check
} // calculation check on errors

void Kinematics::storeData(int &ID,MemorySpace &cpyMem,int &rotation,float &A,float &B){
   int j;
    for(int i = 1; i <= maxUnits; i++){
        j = (i * 10);
        if(ID == j){
            cpyMem.newPosition[(i - 1)][storeHip] = rotation; 
            cpyMem.newPosition[(i - 1)][storeArm] = A; 
            cpyMem.newPosition[(i - 1)][storeToo] = B;    
        }
    } 
}

void Kinematics::unitPosition(int ID,MemorySpace &mem,int rotation,int height, int distance){ 
    storeHeightDistance(ID,mem,height,distance); 
      
    _offset = Zoffset + height;
    L = sqrt(pow(_offset,2) + pow((distance - Coxa),2));
    
    dutyA = (acos(_offset / L)* 180 / PI) + \
            (acos((pow(Tibia,2)- pow(Femur,2)- pow(L,2)) / \
            (-2 * Femur * L))* 180 / PI);
    
    
    dutyB = (acos((pow(L,2)- pow(Tibia,2)- pow(Femur,2)) / \
            (-2 * Tibia * Femur))* 180 / PI);
        
    dutyB = 180 - dutyB;    
    
    /*
     *  when NAN nothing happens
     *  Give error and do nothing
     *  new[0][1] = last[0][1];
     */
    
    if(isnan(dutyA) || isnan(dutyB) ){        
        storeErrorMsg(ID,mem);                                
    } // NAN error function
    
    /*
    *   when calculation is a number give new position
    *   If new value > 180 || < 0 then
    *   new value = 180 || 0 + calculation error msg.
    */
    else
    {
        checkCalculation(ID,mem,rotation,dutyA,dutyB);
        storeData(ID,mem,rotation,dutyA,dutyB);      
    } 
}

void Kinematics::exeServo(int ID,MemorySpace &cpyMem){
    servoAddress = addressPlace[ID][_address];
    servoType = addressPlace[ID][_servoType];
            
    lastValue = cpyMem.lastPosition[ (addressPlace[ID][_row]) ][ (addressPlace[ID][_column]) ];
    newValue = cpyMem.newPosition[ (addressPlace[ID][_row]) ][ (addressPlace[ID][_column]) ];
    flagStatus = cpyMem.addressFlags[ID][flag1];
            
    /*
    * If flag status = 1 : True then don't rotate the servo
    * If flag status = 0 : False then continue
    *
    */
    if(flagStatus == 0){
                
        /*
        *   If the new position is smaller than the old position then
        *   old position must decrease
        *   update Last value
        */
                
        if(newValue < lastValue){
            lastValue--;
            SetServo.position(servoType,servoAddress,lastValue);
            cpyMem.lastPosition[ (addressPlace[ID][_row]) ][ (addressPlace[ID][_column]) ] = lastValue;
        }
                
        /*
        *   If the new position is bigger than the old position then
        *   the old position must increase
        *   update Last value
        */
                
        if(newValue > lastValue){
            lastValue++;
            SetServo.position(servoType,servoAddress,lastValue);
            cpyMem.lastPosition[ (addressPlace[ID][_row]) ][ (addressPlace[ID][_column]) ] = lastValue;
         }
         
         /*
         *   If the new position is equal to the old position then
         *   flagStatus = 1
         */
                
         if(newValue == lastValue){
            cpyMem.addressFlags[ID][flag1] = _error;
         }        
    } 
}

void Kinematics::exeKinematics(MemorySpace &mem){
    for(int i = 0; i < fullLoop; i++){
        for(int j = 0; j < maxServoID; j++){
            exeServo(j,mem);
        } // loop trough all servos
    } // full Loop = degrees = 180*  
    
    for(int i = 0; i < maxServoID; i++){
        mem.addressFlags[i][0] = _nerror;
    } // reset all addressFlags  
}
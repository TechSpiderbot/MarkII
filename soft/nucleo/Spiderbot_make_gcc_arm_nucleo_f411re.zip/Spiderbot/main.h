#ifndef MBED_main_H
#define MBED_main_H

#include "mbed.h"

#include "Serial.h"
#include "setup.h"
#include "DRV8833.h"

#include "KinematicsV1.h"
#include "MemorySpace.h"

#include <string>
#include <sstream>
#include "NeuroNetwork.h"

#define DEBUG
#define DISPLAY
//get reworked
bool Bbtn1 = false;
bool Bbtn2 = false;

bool pressedShort = false;
bool pressedLong = false;
bool buttonPressed = false;
int buttonNumb;

enum States {MAIN,SETTINGS,MODULES,STATE,EXIT};

#define numOfMainScreens  5
string Main_screen[numOfMainScreens][2] = {
    {"MENU\n"       ,"ACTIVATED\n"},
    {"SETTINGS\n"   ,"ACTIVATED\n"},
    {"MODULES\n"    ,"ACTIVATED\n"},
    {"STATE\n"      ,"ACTIVATED\n"},
    {"EXIT\n"       ,"ACTIVATED\n"}
};

#define numOfModulesScreens 13
string MODULES_screen[numOfModulesScreens][2]= {
    {"Container\n"      ,"\n"},
    {"Cont-Sonar\n"     ,"\n"},
    {"Body-Sonar\n"     ,"\n"},
    {"Body-IR\n"        ,"\n"},
    {"Body-Gymble\n"    ,"\n"},
    {"Body-Compass\n"   ,"\n"},
    {"Tibia-R-B\n"      ,"\n"},
    {"Tibia-L-B\n"      ,"\n"},
    {"Tibia-R-F\n"      ,"\n"},
    {"Tibia-L-F\n"      ,"\n"},
    {"PS2 Controller\n" ,"\n"},
    {"Ping Server..\n"  ,"\n"},
    {"BACK\n"           ,"\n"}
};

#endif
#ifndef MBED_WalkOrient_H
#define MBED_WalkOrient_H

#include "mbed.h"
#include "Serial.h"

class WalkOrient{
public:
    void setup();
    void startAction(int*,int);
private:

};

#endif
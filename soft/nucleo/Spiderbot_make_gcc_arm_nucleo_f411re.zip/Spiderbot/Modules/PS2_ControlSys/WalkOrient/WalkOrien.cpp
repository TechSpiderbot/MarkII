#include "WalkOrient.h"

Serial cp1(USBTX,USBRX); 

void WalkOrient::setup(){
    cp1.format(8, Serial::None, 1);
    cp1.baud(9600);   
}

void WalkOrient::startAction(int* a,int b){
    if((b >= 0) && (b <= 100)){
        switch(*a){
            case 0:
                cp1.printf("Select \n\r");
                break;
            case 1:
                cp1.printf("joystick Left \n\r");
                break;
            case 2:
                cp1.printf("joystick Right \n\r");
                break;
            case 3:
                cp1.printf("Start \n\r");
                break;
            case 4:
                cp1.printf("Up \n\r");
                break;
            case 5:
                cp1.printf("Right \n\r");
                break;    
            case 6:
                cp1.printf("Down \n\r");
                break;
            case 7:
                cp1.printf("Left \n\r");
                break;
            case 8:
                cp1.printf("L-2 \n\r");
                break;
            case 9:
                cp1.printf("R-2 \n\r");
                break;
            case 10:
                cp1.printf("L-1 \n\r");
                break;
            case 11:
                cp1.printf("R-1 \n\r");
                break;
            case 12:
                cp1.printf("Triangle \n\r");
                break;
            case 13:
                cp1.printf("Circle \n\r");
                break;
            case 14:
                cp1.printf("Cross \n\r");
                break;
            case 15:
                cp1.printf("Square \n\r");
                break;
            /*case 16:
            case 17:
            case 18:
            case 19:*/
        
            case 20:
                cp1.printf("j_Left up %i\n\r",b);
                break;
            case 21:
                cp1.printf("j_Left down %i\n\r",b);
                break;
            case 22:
                cp1.printf("j_Left left %i\n\r",b);
                break;
            case 23:
                cp1.printf("j_Left right %i\n\r",b);
                break;
            case 24:
                cp1.printf("j_Right up %i\n\r",b);
                break;
            case 25:
                cp1.printf("j_Right down %i\n\r",b);
                break;
            case 26:
                cp1.printf("j_Right left %i\n\r",b);
                break;
            case 27:
                cp1.printf("j_Right right %i\n\r",b);
                break;
        }
    }
}
#ifndef MBED_btnValues_H
#define MBED_btnValues_H

struct btnValues{
    int action;
    int value;
};
    
#endif